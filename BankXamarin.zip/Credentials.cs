namespace Banking
{
    public class Credentials
    {
        
    }

}